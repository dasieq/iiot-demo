SELECT id, timestamp, topic, value, unit, quality
FROM tag_history
WHERE timestamp >= now() - interval '24 hours'
ORDER BY timestamp DESC